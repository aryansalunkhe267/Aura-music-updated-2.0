package com.example.utils

import android.media.MediaMetadataRetriever
import java.util.regex.Pattern

/**
 * Strips parenthetical translations and trailing tags:
 * - Removes any text inside parentheses: (Official Audio), (Translation), (ਟਵੰਟੀ ਨਾਈਨ ਫਾਈਵ)
 * - Removes text inside square brackets: [Official Audio], [Remastered]
 * Strictly preserves the original native script verbatim without any automated transliteration or translation.
 */
fun cleanMetadataString(raw: String): String {
    return raw
        .replace(Regex("""\s*\([^)]*\)"""), "")
        .replace(Regex("""\[[^\]]*\]"""), "")
        .trim()
}

/**
 * Raw metadata extractor and sanitizer that strictly preserves the original script verbatim.
 * Disables automated transliteration or translation, while stripping trailing parenthetical translations
 * or bracketed tags (e.g., removing "(Official Audio)" or "(ਟਵੰਟੀ ਨਾਈਨ ਫਾਈਵ)").
 */
object MetadataSanitizer {

    private val FILE_EXTENSION_PATTERN = Pattern.compile("""(?i)\.(mp3|m4a|flac|wav|aac|ogg|opus)$""")

    fun cleanMetadataString(raw: String): String = com.example.utils.cleanMetadataString(raw)

    /**
     * Reads raw TIT2 ID3v2 tag or MediaStore title, strictly preserving the original script 
     * without automated transliteration or translation, while stripping trailing parenthetical 
     * translations or bracketed tags (e.g., remove "(Official Audio)" or "(ਟਵੰਟੀ ਨਾਈਨ ਫਾਈਵ)").
     */
    fun sanitizeTitle(rawTitle: String?): String {
        if (rawTitle.isNullOrBlank()) return "Unknown Title"
        var title = rawTitle.trim()
        title = FILE_EXTENSION_PATTERN.matcher(title).replaceAll("").trim()
        title = cleanMetadataString(title)
        return if (title.isBlank()) rawTitle.trim() else title
    }

    /**
     * Returns the raw artist verbatim, strictly preserving native script without automated translation.
     */
    fun sanitizeArtist(rawArtist: String?): String {
        if (rawArtist.isNullOrBlank()) return "Unknown Artist"
        val artist = cleanMetadataString(rawArtist.trim())
        return if (artist.isBlank()) "Unknown Artist" else artist
    }

    /**
     * Returns the raw album name verbatim, strictly preserving native script without automated translation.
     */
    fun sanitizeAlbum(rawAlbum: String?): String {
        if (rawAlbum.isNullOrBlank()) return "Unknown Album"
        val album = cleanMetadataString(rawAlbum.trim())
        return if (album.isBlank()) "Unknown Album" else album
    }

    /**
     * Extracts raw TIT2 tag from local audio file using MediaMetadataRetriever
     * and sanitizes it preserving the original script.
     */
    fun extractAndSanitizeTitle(dataPath: String?, mediaStoreTitle: String?): String {
        var rawTitle = mediaStoreTitle
        if (!dataPath.isNullOrBlank()) {
            try {
                val retriever = MediaMetadataRetriever()
                retriever.setDataSource(dataPath)
                val id3Title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                retriever.release()
                if (!id3Title.isNullOrBlank()) {
                    rawTitle = id3Title
                }
            } catch (_: Exception) {}
        }
        return sanitizeTitle(rawTitle)
    }
}
