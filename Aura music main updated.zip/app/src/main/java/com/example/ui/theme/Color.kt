package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SpotifyGreen = Color(0xFF1DB954)
val SpotifyGreenVariant = Color(0xFF1ED760)
val NeonMint = Color(0xFF00F5D4)
val ElectricCyan = Color(0xFF00E5FF)

val OneUIDarkBackground = Color(0xFF000000)
val OneUISurfaceDark = Color(0xFF121212)
val OneUICardElevated = Color(0xFF1E1E1E)
val OneUICardBorder = Color(0xFF2C2C2C)
val OneUITextPrimary = Color(0xFFFFFFFF)
val OneUITextSecondary = Color(0xFFAAAAAA)
val OneUITextMuted = Color(0xFF757575)

val MoodEnergeticColor = Color(0xFFFF5722)
val MoodUpbeatColor = Color(0xFFFFB300)
val MoodChillColor = Color(0xFF00B0FF)
val MoodMelancholyColor = Color(0xFFAB47BC)
val MoodCalmColor = Color(0xFF26A69A)

